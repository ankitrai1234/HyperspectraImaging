from flask import Flask, request, render_template, jsonify
import numpy as np
import joblib
import tensorflow as tf
from tensorflow.keras.losses import MeanSquaredError
import prediction  

app = Flask(__name__)

# Load models and scalers
custom_objects = {"mse": MeanSquaredError()}
model = tf.keras.models.load_model("models/best_lstm_model.h5", custom_objects=custom_objects)
scaler = joblib.load("models/scaler.pkl")
pca = joblib.load("models/pca.pkl")
output_scaler = joblib.load("models/output_scaler.pkl")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        
        input_data = request.form['input_data']
        input_features = np.array([float(x) for x in input_data.split(',')]).reshape(1, -1)

        
        input_scaled = scaler.transform(input_features)
        input_pca = pca.transform(input_scaled)

        
        input_final = input_pca.reshape((1, 1, 3))

       
        prediction_scaled = model.predict(input_final)

       
        final_output = output_scaler.inverse_transform(prediction_scaled)

       
        return jsonify({'prediction': final_output.tolist()})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)